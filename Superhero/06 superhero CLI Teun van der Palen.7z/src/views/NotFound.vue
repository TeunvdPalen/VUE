<template>
	<h1>This is not the page you are looking for :)</h1>
</template>

<style scoped>
h1 {
	text-align: center;
}
</style>
